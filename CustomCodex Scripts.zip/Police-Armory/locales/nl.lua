Locales['nl'] = {
    ['armory_menu'] = 'Wapenarsenaal Menu',
    ['return_weapon'] = 'Wapen Terugbrengen',
    ['greeting'] = 'Hallo Agent, ben je klaar om dienst te nemen?',
    ['instruction'] = 'Selecteer je wapenarsenaal.',
    ['safety'] = 'Veiligheid eerst.',
    ['armory_title'] = 'Wapenarsenaal Menu',
    ['return_weapon_title'] = 'Wapen Terugbreng Menu',
    ['return_weapon_label'] = 'Wapen Terugbrengen',
    ['purchase_successful'] = 'Je hebt het wapen succesvol gekocht.',
    ['return_weapon_successful'] = 'Je hebt het wapen teruggebracht.',
}
