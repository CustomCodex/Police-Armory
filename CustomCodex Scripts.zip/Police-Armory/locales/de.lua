Locales['de'] = {
    ['armory_menu'] = 'Waffenlager Menü',
    ['return_weapon'] = 'Waffe Zurückgeben',
    ['greeting'] = 'Hallo Beamter, bist du bereit für den Dienst?',
    ['instruction'] = 'Bitte wähle dein Waffenlager aus.',
    ['safety'] = 'Sicherheit zuerst.',
    ['armory_title'] = 'Waffenlager Menü',
    ['return_weapon_title'] = 'Waffe Zurückgeben Menü',
    ['return_weapon_label'] = 'Waffe Zurückgeben',
    ['purchase_successful'] = 'Du hast die Waffe erfolgreich gekauft.',
    ['return_weapon_successful'] = 'Du hast die Waffe zurückgebracht.',
}
