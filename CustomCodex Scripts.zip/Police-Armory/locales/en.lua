Locales['en'] = {
    ['armory_menu'] = 'Armory Menu',
    ['return_weapon'] = 'Return Weapon',
    ['greeting'] = 'Hello Officer, you ready to go on duty?',
    ['instruction'] = 'Please select your armory.',
    ['safety'] = 'Safety first.',
    ['armory_title'] = 'Armory Menu',
    ['return_weapon_title'] = 'Return Weapon Menu',
    ['return_weapon_label'] = 'Return Weapon',
    ['purchase_successful'] = 'You have successfully purchased the weapon.',
    ['return_weapon_successful'] = 'You have returned the weapon.',
}
