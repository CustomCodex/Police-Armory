Locales['es'] = {
    ['armory_menu'] = 'Menú de Armería',
    ['return_weapon'] = 'Devolver Arma',
    ['greeting'] = 'Hola Oficial, ¿estás listo para comenzar el turno?',
    ['instruction'] = 'Por favor selecciona tu armería.',
    ['safety'] = 'Primero la seguridad.',
    ['armory_title'] = 'Menú de Armería',
    ['return_weapon_title'] = 'Menú de Devolución de Armas',
    ['return_weapon_label'] = 'Devolver Arma',
    ['purchase_successful'] = 'Has comprado el arma con éxito.',
    ['return_weapon_successful'] = 'Has devuelto el arma.',
}
